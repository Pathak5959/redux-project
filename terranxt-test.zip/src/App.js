import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchTodos } from "./redux/slice/todo";
import "./App.css";

function App() {
  const dispatch = useDispatch();
  const todoState = useSelector((state) => state.todo);

  return (
    <div className="App">
      <div className="component">TERRANXT TEST</div>
      {todoState.isLoading ? (
        <div className="loder">Loading....</div>
      ) : (
        <div className="mainpage">
          <center>
            <div className="center-container">
              <div className="center-container2">
                <button
                  className="btn-welcome"
                  onClick={() => dispatch(fetchTodos())}
                >
                  Fetch Todos
                </button>
              </div>
            </div>
          </center>
        </div>
      )}
      {todoState.data && (
        <div>
          {todoState.data.map((todo) => (
            <div key={todo.id} className="fetch-data">
              {todo.title}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
